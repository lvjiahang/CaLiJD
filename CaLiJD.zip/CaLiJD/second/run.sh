#!/bin/bash  

for i in $(seq 11 21)  
do   
echo "===> start sequence ${i}.";
/home/optobot-01/anaconda3/envs/clo/bin/python \
    eval.py --device 0 --sequence $i --outDIR submission

echo "===> finish sequence ${i}.";

done
