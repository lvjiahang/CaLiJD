import numpy as np
import IoU
import DIoU
# box : [左上角x坐标，左上角y坐标，右下角x坐标，右下角y坐标]
box1 = [0, 0, 6, 8]
box2 = [3, 2, 9, 10]
# CIoU
def CIoU(box1, box2):
    x1, y1, x2, y2 = box1
    x3, y3, x4, y4 = box2
    # box1的宽：box1_w，box1的高：box1_h，
    box1_w = boxes[n, 2]  - boxes[n, 0]
    box1_h = boxes[n, 3]  - boxes[n, 1]
    # box2的宽：box2_w，box2的高：box2_h，
    box2_w = query_boxes[k, 2] - query_boxes[k, 0]
    box2_h = query_boxes[k, 3] - query_boxes[k, 1]
    #iou = IoU(box1, box2)
    #diou = DIoU(box1, box2)

    # v用来度量长宽比的相似性
    v = (4 / (np.pi) ** 2) * (np.arctan(int(box2_w / box2_h)) - np.arctan(int(box1_w / box1_h)))
    # α是权重函数
    a = v / ((1 + iou) + v)
    ciou = diou - a * v
    return ciou

print(CIoU(box1, box2))

