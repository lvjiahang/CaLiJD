import torch
import torch.nn.functional as F

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
class SimplifiedSelfAttention(torch.nn.Module):
    def __init__(self, embed_size):
        super(SimplifiedSelfAttention, self).__init__()
        self.scale_factor = torch.sqrt(torch.FloatTensor([embed_size]))
        #self.conv = torch.nn.Conv2d(54,1,1)
    def forward(self, x):
        # 注意：这个简化版没有使用额外的转换矩阵（W_q, W_k, W_v）
        # 计算query和key的点积，维度为(batch_size, seq_len, seq_len)
        si = x.shape[3]
        wid = (si//20)*20
        x = x[:,:,:,:wid:20].to(device)

        b,c,w,h = x.size()

        x = x.view(b,c,w*h).permute(0,2,1).contiguous()
        attention_scores = torch.matmul(x, x.transpose(-2, -1)) / self.scale_factor.to(device)

        # 应用softmax获取注意力权重
        attention_weights = F.softmax(attention_scores, dim=-1)

        # 生成加权的value
        weighted_value = torch.matmul(attention_weights, x).permute(0,2,1).view(b,c,w,h).contiguous()

        return weighted_value



