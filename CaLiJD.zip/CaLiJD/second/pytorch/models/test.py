import torch
from voxelnet import VoxelNet

input = torch.zeros(3,4,5)

output = VoxelNet(input)
