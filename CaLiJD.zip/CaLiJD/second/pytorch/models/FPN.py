import torch.nn as nn
import torch.nn.functional as F
class FPN(nn.Module):
    def __init__(self, in_channels_list, out_channels):
        super(FPN, self).__init__()
        self.out_channels = out_channels
        self.inner_blocks = nn.ModuleList()
        self.layer_blocks = nn.ModuleList()

        for in_channels in in_channels_list:
            if in_channels == 0:
                continue
            inner_block = nn.Conv2d(in_channels, out_channels, 1)
            layer_block = nn.Conv2d(out_channels, out_channels, 3, padding=1)
            self.inner_blocks.append(inner_block)
            self.layer_blocks.append(layer_block)

        self.toplayer = nn.Conv2d(in_channels_list[-1], out_channels, 1)

    def forward(self, x):
        last_inner = self.toplayer(x[-1])
        results = []
        results.append(last_inner)
        for feature, inner_block, layer_block in zip(
            x[:-1][::-1], self.inner_blocks[::-1], self.layer_blocks[::-1]
        ):
            if not feature.size()[2:]:
                continue
            upsampled = F.interpolate(last_inner, size=feature.size()[2:], mode='nearest')
            last_inner = inner_block(feature) + upsampled
            results.insert(0, layer_block(last_inner))

        return tuple(results)
