import torch
import torch.nn as nn


class CAM(nn.Module):
    def __init__(self, inc, fusion='adaptive'):
        super().__init__()

        assert fusion in ['weight', 'adaptive', 'concat'] #三种融合方式
        self.fusion = fusion

        self.conv1 = nn.Conv2d(inc, inc, 1, 1, 0, 1, 1)
        self.conv2 = nn.Conv2d(inc, inc, 1, 1, 0, 1, 2)
        if inc == 18:
            self.conv3 = nn.Conv2d(inc, inc, 1, 1, 0, 1, 18)
        elif inc == 32:
            self.conv3 = nn.Conv2d(inc, inc, 1, 1, 0, 1, 32)
        else:
            self.conv3 = nn.Conv2d(inc, inc, 1, 1, 0, 1,36)


        self.fusion_1 = nn.Conv2d(inc, inc, 1)
        self.fusion_2 = nn.Conv2d(inc, inc, 1)
        self.fusion_3 = nn.Conv2d(inc, inc, 1)

        if self.fusion == 'adaptive':
            self.fusion_4 = nn.Conv2d(inc * 3, 3, 1)

    def forward(self, x):
        x1 = self.conv1(x)
        x2 = self.conv2(x)
        x3 = self.conv3(x)

        if self.fusion == 'weight':
            return self.fusion_1(x1) + self.fusion_2(x2) + self.fusion_3(x3)
        elif self.fusion == 'adaptive':
            fusion = torch.softmax(
                self.fusion_4(torch.cat([self.fusion_1(x1), self.fusion_2(x2), self.fusion_3(x3)], dim=1)), dim=1)
            x1_weight, x2_weight, x3_weight = torch.split(fusion, [1, 1, 1], dim=1)
            return x1 * x1_weight + x2 * x2_weight + x3 * x3_weight
        else:
            return torch.cat([self.fusion_1(x1), self.fusion_2(x2), self.fusion_3(x3)], dim=1)

