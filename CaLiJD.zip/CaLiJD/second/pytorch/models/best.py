import torch
from torch import nn
from torch.nn import functional as F
import spconv
import sys
sys.path.append('/home/optobot-01/ljh/PycharmProjects/pythonProject/CLOCS/CLOCs')
import torchplus
from torchplus.nn import Empty, GroupNorm, Sequential
from torchplus.ops.array_ops import gather_nd, scatter_nd
from torchplus.tools import change_default_args
import sys
sys.path.append('/home/optobot-01/ljh/PycharmProjects/pythonProject/CLOCS/CLOCs/second')
from models.CAM import CAM
if '/opt/ros/kinetic/lib/python2.7/dist-packages' in sys.path:
    sys.path.remove('/opt/ros/kinetic/lib/python2.7/dist-packages')


#from models.RCCA import RCCAModule
class FPN(nn.Module):
    def __init__(self, channels):
        super(FPN, self).__init__()
        self.up_sample = nn.Upsample(scale_factor=1, mode='nearest')
        self.conv1x1_1 = nn.Conv2d(channels[1], channels[0], kernel_size=1)
        self.conv1x1_2 = nn.Conv2d(channels[2], channels[0], kernel_size=1)

    def forward(self, features):
        # features is a list of feature maps from different layers
        p3_upsampled = self.up_sample(features[2])
        #print(p3_upsampled.size)
        p3_upsampled = self.conv1x1_2(p3_upsampled)

        p2_upsampled = self.up_sample(features[1])
        #print(p2_upsampled.size)
        p2_upsampled = self.conv1x1_1(p2_upsampled)
        target_size = features[0].shape[2:]
        #print(target_size.size)
        #print(features[1].shape)
        p2_upsampled = F.interpolate(p2_upsampled, size=target_size, mode='nearest')
        p3_upsampled = F.interpolate(p3_upsampled, size=target_size, mode='nearest')
        # Element-wise addition
        p1 = features[0] + p2_upsampled + p3_upsampled

        return p1
class fusion(nn.Module):
    def __init__(self):
        super(fusion, self).__init__()
        self.name = 'fusion_layer'
        self.conv0 = Sequential(nn.Conv2d(4,24,1),
                                nn.ReLU())
        self.corner_points_feature = Sequential(
            nn.Conv2d(24,48,1),
            nn.ReLU(),
            nn.Conv2d(48,96,1),
            nn.ReLU(),
            nn.Conv2d(96,96,1),
            nn.ReLU(),
            nn.Conv2d(96,36,1),
        )
        #self.conv0 = Sequential(nn.Conv2d(4, 36, 1),
         #                       nn.ReLU())
        self.corner_points_feature1 = Sequential(
            nn.Conv2d(4, 36, 1),
            nn.ReLU(),
            nn.Conv2d(36, 18, 1),
            nn.ReLU(),
            nn.Conv2d(18, 18, 1),
            nn.ReLU(),
            nn.Conv2d(18, 4, 1),
        )
        self.relu = nn.ReLU()
        self.conv1 = nn.Conv2d(4,18,1)
        self.conv2 = nn.Conv2d(18, 36, 1)
        self.conv3 = nn.Conv2d(36, 36, 1)
        self.conv4 = nn.Conv2d(18, 1, 1)
        self.conv5 = nn.Conv2d(36, 1, 1)
        self.fpn = FPN([18, 36, 36])
        #self.cam0 = CAM(int(4))
        self.cam1 = CAM(int(18))
        self.cam2 = CAM(int(36))
        self.cam3 = CAM(int(36))
        #self.RCCA = RCCAModule(54,54)
        # self.fuse_2d_3d= Sequential(
        #     nn.Conv2d(4,18,1),
        #     nn.ReLU(),
        #     nn.Conv2d(18,36,1),
        #     nn.ReLU(),
        #     nn.Conv2d(36,36,1),fusion
        #     nn.ReLU(),
        #     nn.Conv2d(36,1,1),
        # )
        self.shortcut_conv = nn.Conv2d(4, 1, 1)
        self.maxpool = Sequential(
            nn.MaxPool2d([200,1],1),
        )


    def forward(self,input_1,tensor_index):
        flag = -1
        if tensor_index[0,0] == -1:
            out_1 = torch.zeros(1,200,70400,dtype = input_1.dtype,device = input_1.device)
            out_1[:,:,:] = -9999999
            flag = 0
        else:
            fpn_output = self.conv0(input_1)
            output = self.corner_points_feature(fpn_output)
            #input_1 = self.corner_points_feature1(input_1)
            input_1 = self.corner_points_feature1(input_1)
            c1 = self.relu(self.conv1(input_1))
            cam_out1 = self.cam1(c1)
            c2 = self.relu(self.conv2(c1))
            cam_out2 = self.cam2(c2)
            c3 = self.relu(self.conv3(c2))
            cam_out3 = self.cam3(c3)
            fpn_output = self.fpn([cam_out1, cam_out2, cam_out3])
           
            #fpn_output = self.RCCA( fpn_output )
            out = self.conv4(fpn_output)
            out1 = self.conv5(output)
            #out1 = self.shortcut_conv(input_1)
            #x = self.fuse_2d_3d(input_1)
            x = out1+out            #print(x.shape)
            out_1 = torch.zeros(1,200,70400,dtype = input_1.dtype,device = input_1.device)
            out_1[:,:,:] = -9999999
            out_1[:,tensor_index[:,0],tensor_index[:,1]] = x[0,:,0,:]
            flag = 1
        x = self.maxpool(out_1)
        #x, _ = torch.max(out_1,1)
        x = x.squeeze().reshape(1,-1,1)
        return x,flag
