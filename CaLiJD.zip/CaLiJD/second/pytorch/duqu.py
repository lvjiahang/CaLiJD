import pickle

# 替换为你的.pkl文件路径
file_path = 'result.pkl'

# 读取.pkl文件
with open(file_path, 'rb') as file:
    data = pickle.load(file)

# 现在data包含了.pkl文件中的对象
print(data)